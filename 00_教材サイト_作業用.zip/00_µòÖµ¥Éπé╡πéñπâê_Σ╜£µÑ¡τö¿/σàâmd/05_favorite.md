
# **05_２ページ目のHTML（favorite.html）**

## **２ページ目のHTMLを書いてみよう**

- [ ] index.htmlをコピー(07_favorite.html)
- 共通部分を残していらない部分を削除
- `class="wrapper"`の中を削除 

<br><br>

- [ ] グループ化(08_favorite.html)

![html](img/05_favorite1-1.png)

- `<div class>`（教科書P147）

<br><br>

- [ ] 見出し(09_favorite.html) （教科書P59）
- `<h2><h3>`

<br><br>

- [ ] 文章(10_favorite.html)（教科書P61）
- `<p>`

<br><br>
  
- [ ] リスト(11_favorite.html)（教科書P67）
- `<ul>`

<br><br>

- [ ] リンク(12_favorite.html)（教科書P65）
- `<a>`

<br><br>

- [ ] テーブル(13_favorite.html)（教科書P69）
- `<table>`

<br>