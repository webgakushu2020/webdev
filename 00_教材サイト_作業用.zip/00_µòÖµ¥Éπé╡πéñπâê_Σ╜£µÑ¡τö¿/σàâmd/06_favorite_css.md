
# **06_２ページ目のCSS（style.css）**

## **２ページ目のCSSを書いてみよう**

- [ ] 線をつける(18_style.css)(19_style.css)（教科書P140）
- `border-left`

<br><br>

- [ ] 外側の余白をつける(20_style.css) （教科書P134）
- `margin-bottom`
  
- [ ] 要素を横並びにする(20_style.css) （教科書P153）
- `display:flex`

<br><br>

- [ ] テーブルの装飾(21_style.css)（教科書なし）
- `padding`
- `margin`

<br><br>
