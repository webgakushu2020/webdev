
# **00_連絡事項**

## **自己紹介**

## **オリエンテーション動画**

- 水曜日と金曜日の演習
- 演習の他にマンツーマンサポート

<br>

## **マンツーマン指導について**

![info](img/00_info1-3.jpg)
![info](img/00_info1-4.jpg)

https://drive.google.com/file/d/1rmTs_7L-ARmVHh6kUoCYsBv4qmJIYrcT/view?usp=sharing